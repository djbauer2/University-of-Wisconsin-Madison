/**
 * @author See Contributors.txt for code contributors and overview of BadgerDB.
 *
 * @section LICENSE
 * Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison.
 */

#include "btree.h"
#include "filescan.h"
#include "exceptions/bad_index_info_exception.h"
#include "exceptions/bad_opcodes_exception.h"
#include "exceptions/bad_scanrange_exception.h"
#include "exceptions/no_such_key_found_exception.h"
#include "exceptions/scan_not_initialized_exception.h"
#include "exceptions/index_scan_completed_exception.h"
#include "exceptions/file_not_found_exception.h"
#include "exceptions/file_open_exception.h"
#include "exceptions/end_of_file_exception.h"
#include "exceptions/bad_buffer_exception.h"
#include "exceptions/page_pinned_exception.h"

//#define DEBUG

namespace badgerdb
{

	// -----------------------------------------------------------------------------
	// BTreeIndex::BTreeIndex -- Constructor
	// -----------------------------------------------------------------------------

	BTreeIndex::BTreeIndex(const std::string &relationName,
						   std::string &outIndexName,
						   BufMgr *bufMgrIn,
						   const int attrByteOffset,
						   const Datatype attrType)
	{
		/*
	BTreeIndex Constructor. Check to see if the corresponding index file exists. If so, open the file.If not, create it and insert entries for every tuple in the base relation using FileScan class.

		Parameters:
		relationName – Name of file.
		outIndexName – Return the name of index file.
		bufMgrIn – Buffer Manager Instance
		attrByteOffset – Offset of attribute, over which index is to be built, in the record
		attrType – Datatype of attribute over which index is built
	*/

		//develop indexName given relationName and attrByteOffset as specified in docs
		//std::cout << relationName << std::endl; //TODO remove
		std::string indexName;
		std::ostringstream indexString;
		indexString << relationName << '.' << attrByteOffset;

		//indexName is the name of the index file
		indexName = indexString.str();
		//then return, by reference, the indexName to outIndexName
		outIndexName = indexName;

		//set private members that are available directly from parameters or by default.
		this->bufMgr = bufMgrIn;
		this->attributeType = attrType;
		this->attrByteOffset = attrByteOffset;
		this->scanExecuting = false;

		//DESIGN NOTE: leafOccupancy & nodeOccupancy will both be = 0 when the tree is empty!
		//set leafOccupancy to 0, since the B+ tree is empty.
		this->leafOccupancy = 0;
		//set nodeOccupancy to 0 since the tree is empty.
		this->nodeOccupancy = 0;

		//Dedicated header page for the B+ tree file too for storing METADATA of the index. Set page # later.
		Page *dedicatedMetaHeaderPage;

		//check to see if the corresponding index file exists. If so, open the file.
		try
		{

			//tries to load a new BlobFile. If file does not exist, it will throw a FileNotFoundException which is caught later.
			//loads the blob,
			BlobFile *blob = new BlobFile(outIndexName, false);

			//since file exists, assign the opened blob to file.
			this->file = blob;

			//set headerPageNum to the first page of file, which is the first page.
			this->headerPageNum = this->file->getFirstPageNo();

			//returns pointer to page by reference. Updates headerPageNum by reference (I think)
			this->bufMgr->readPage(file, this->headerPageNum, dedicatedMetaHeaderPage); //takes file, pageNo, page as param

			//get rootPageNo from metaData page
			IndexMetaInfo *metaData = reinterpret_cast<IndexMetaInfo *>(dedicatedMetaHeaderPage);
			this->rootPageNum = metaData->rootPageNo;

			// Check that relation attribures match, if not throw bad index info exceptions
			/*
			if (metaData->attrType != this->attributeType)
			{
				throw BadIndexInfoException("Attribute type mismatch");
			}

			if (metaData->attrByteOffset != this->attrByteOffset)
			{
				throw BadIndexInfoException("Byte offset mismatch");
			}
			*/

			// convert the meta data relation name to a std::string, then we are able to compare.
			std::string metaRelationName(metaData->relationName);
			//std::cout << metaRelationName << ", " << outIndexName << std::endl;
			
			//strcpy(metaData->relationName, metaRelationName.c_str());
			//std::remove_const<char* const>::type c;
			//strcpy(metaRelationName.c_str(), metaData->relationName);

			//since the blob already exists, metaRelationName already exits.
			/*
			if (metaRelationName != outIndexName)
			{
				std::cout << metaRelationName << ", " << outIndexName << std::endl;
				throw BadIndexInfoException("Relation name mismatch");
			}
			*/
		
			// Done with the dedicatedMetaHeaderPage so unpin from the buffer manager
			this->bufMgr->unPinPage(file, this->headerPageNum, false);

			return;
		}
		catch (FileNotFoundException &e)
		{ //file indexFile does NOT exist already

			//CREATE NEW

			//since blobFile is not found, create a blob by changing the parameter to true.
			//loads the blob, which is a "raw file" - ie) has no page structure on top of if
			BlobFile *blob = new BlobFile(outIndexName, true);

			//assign new blobFile to this file.
			this->file = blob;

			// Create IndexMetaInfo Struct
			IndexMetaInfo *metaData;

			// Need to create a new header page for the blob file meta info
			Page *newDedicatedMetaHeaderPage;
			this->bufMgr->allocPage(file, this->headerPageNum, newDedicatedMetaHeaderPage);

			//need to create new root page. So now rootPage will contain a pointer to the root.
			//... and rootPageNum will contain the rootPageNum to set metaData.
			Page *rootPage;
			this->bufMgr->allocPage(this->file, this->rootPageNum, rootPage);

			// Initialize the meta data struct
			metaData = reinterpret_cast<IndexMetaInfo *>(newDedicatedMetaHeaderPage);

			//set metaData members.
			metaData->rootPageNo = this->rootPageNum; // Page number of root page
			//CHECK that this works
			strcpy(metaData->relationName, outIndexName.c_str()); // relation name as calculated above
			metaData->attrByteOffset = this->attrByteOffset;	  // Offset of attribute
			metaData->attrType = this->attributeType;			  // Type of the attribute

			// Done with rootpage so unpin from buffer manager
			this->bufMgr->unPinPage(file, rootPageNum, false);

			// Done with the meta header page so unpin from the buffer manager
			this->bufMgr->unPinPage(file, this->headerPageNum, true); // Page was modified, so mark dirty as true

			//read in data from the source
			FileScan *fileScan = new FileScan(relationName, this->bufMgr);  //Why do we use relationName instead of outIndexName TODO debugging
			RecordId recordId;

			while (true)
			{
				try
				{ // Sequentially iterate through the relation until the end of file is reached

					// Pass in an empty RercordId to start the scanning process: piazza @442
					// RecordId is inialized within the scanNext method
					fileScan->scanNext(recordId);

					// Get the key from the recordId: piazza @419
					std::string keyString = fileScan->getRecord();

					// TODO: Determine which method to get the key is correct
					// void *key = &keyString[this->attrByteOffset]; // interpret as an int
					// void *key = &keyString + attrByteOffset;

					// Get a pointer to the beginning of the keyString
					const char *keyCString = keyString.c_str();

					// User pointer arithmatic and the byte offset to get a pointer to the key
					int keyInt = *((int *)(keyCString + this->attrByteOffset));
					void *key = (void *)keyInt;

					//std::cout << "The Key: " << key << std::endl;

					// Insert entry into the B+ tree
					insertEntry(key, recordId);
				}
				catch (EndOfFileException &e)
				{ //as specified on page 2 of documentation

					//reached end of file, so break from the loop.
					break;
				}
			}
		}
	}

	// -----------------------------------------------------------------------------
	// BTreeIndex::~BTreeIndex -- destructor
	// -----------------------------------------------------------------------------

	BTreeIndex::~BTreeIndex()
	{
		// Clear up any state vars

		// Since pins are unpinned immediatly after use, they are already ALL unpinned!
		//DESIGN NOTE: we will immediatly unpin pages so the constructor doesn't have to.

		//flush the index file by calling bufMgr->flushFile()
		if (false) //
		{
			//Do nothing - since file already doesn't exist.
		}
		else
		{
			try
			{

				//std::cout << "Deconstructor" << std::endl;
				//call endScan to end the scan. Unpins all pages so flushFile(...) can be called next.
				endScan();

				//flushFile. Writes all dirty page to file.
				bufMgr->flushFile(file);

				//delete the file.
				delete (this->file);
			}
			catch (BadBufferException &badBufferE)
			{
				//DESIGN NOTE: We ensure it is not possible for pages to remain pinned
			}
			catch (PagePinnedException &pagePinnedE)
			{
			}
			catch (ScanNotInitializedException &notInitializedE)
			{
			}
			catch (const std::exception &generalException)
			{
				//make sure all other exceptions are caught to satisfy Additional Note #5
			}
		}
	}

	/**
	 * Insert a new entry using the pair <value,rid>.
	 * Start from root to recursively find out the leaf to insert the entry in. The insertion may cause splitting of leaf node.
	 * This splitting will require addition of new leaf page number entry into the parent non-leaf, which may in-turn get split.
	 * This may continue all the way upto the root causing the root to get split. If root gets split, metapage needs to be changed accordingly.
	 * Make sure to unpin pages as soon as you can.
	 * @param key			Key to insert, pointer to integer/double/char string
	 * @param rid			Record ID of a record whose entry is getting inserted into the index.
	 **/
	void BTreeIndex::insertEntry(const void *key, const RecordId rid)
	{
		// Check if tree is empty
		if (nodeOccupancy == 0 && leafOccupancy == 0)
		{ // No keys in any internal nodes or any leaf nodes, so tree must be empty

			// Create a root page
			Page *root;
			this->bufMgr->readPage(file, rootPageNum, root);

			// Inserting the first key into an empty key means the root is a leaf node
			// so cast the root page to a LeafNodeInt
			LeafNodeInt *rootStruct = reinterpret_cast<LeafNodeInt *>(root);

			// Initialize the root struct's members
			rootStruct->rightSibPageNo = 0; // Current entry has no siblings

			// Initilize the record id array, setting each record id value to INT_MAX
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{
				rootStruct->ridArray[i].page_number =INT32_MAX;
			}

			// Initilize the key array, setting each key value to INT_MAX
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{
				rootStruct->keyArray[i] = INT32_MAX;
			}

			// Done with the root page so unpin from buffer pool
			this->bufMgr->unPinPage(file, rootPageNum, true); // Page was written to, so mark as dirty
		}

		// Create a Record ID and Key pair to pass into insert helper method
		RIDKeyPair<int> *ridKeyPair = new RIDKeyPair<int>();

		// Set pair's rid and key members
		//You need to cast void pointer to int pointer, and then dereference the int pointer to get the int. @piazza post
		int intKey = *(int *)(&key);
		//std::cout << intKey << std::endl; //TODO
		ridKeyPair->set(rid, intKey); 


		// Create a PageKeyPair to represent a leaf node returned from insert helper method
		PageKeyPair<int> *leaf;

		// Insert the key, rid pair into the tree, start from root and recusively find a leaf node to insert
		if (nodeOccupancy == 0)
		{

			// Only root node exists, so treat root as a leaf and pass in a level = 1
			leaf = insertEntryHelper(rootPageNum, 1, ridKeyPair);
		}
		else
		{

			// Root is not a leaf, so level = 0
			leaf = insertEntryHelper(rootPageNum, 0, ridKeyPair);
		}

		// If a leaf node is returned from the insert helper, ie is not null, the leaf to insert into is full,
		// keys must be copied upwards, and a new root must be created
		if (leaf != NULL)
		{
			// Create a new root and a new key, so:
			nodeOccupancy++;

			// Store old root reference, will override the class field
			PageId oldRootNum = rootPageNum;

			// Create a new page for the new root
			Page *newRoot;
			PageId newRootNum;

			// Allocate a page in the buffer pool for the root page
			this->bufMgr->allocPage(file, newRootNum, newRoot);

			// New root is not a leaf so cast it to an internal node struct
			NonLeafNodeInt *newRootStruct = reinterpret_cast<NonLeafNodeInt *>(newRoot);

			// Store the new root page id in the class field
			rootPageNum = newRootNum;

			// Reinitiaize the new root's members

			// Root should not be a leaf node unless there hasn't been enough entries to split the intial root
			if (nodeOccupancy >= INTARRAYNONLEAFSIZE)
			{
				newRootStruct->level = 0;
			}
			else
			{
				newRootStruct->level = 1;
			}

			// Initialize root's page array to 0's
			for (int i = 0; i < INTARRAYNONLEAFSIZE + 1; i++)
			{
				newRootStruct->pageNoArray[i] = 0;
			}

			// Copy over information propagated up the tree to the new root
			newRootStruct->keyArray[0] = leaf->key;
			newRootStruct->pageNoArray[0] = oldRootNum;
			newRootStruct->pageNoArray[1] = leaf->pageNo;

			// Update the dedicated meta header page
			Page *metaPage;
			this->bufMgr->readPage(file, this->headerPageNum, metaPage);

			// Cast the page to a meta info stuct
			IndexMetaInfo *metaHeaderPage = reinterpret_cast<IndexMetaInfo *>(metaPage);
			metaHeaderPage->rootPageNo = rootPageNum;

			// Done with the meta header page and then new root page so remove them from the buffer pool
			this->bufMgr->unPinPage(file, newRootNum, true);	// Wrote to the new root page so set dirty bit
			this->bufMgr->unPinPage(file, headerPageNum, true); // Wrote to the header meta page so set dirty bit
		}

		// Delete no longer used variables
		delete leaf;
		delete ridKeyPair;
	}

	/*
	*	Helper method for insertEntry for general cases. 
	*
	*	@param PageId currPageNum tehe curernt page number
	*	@param int currLevel, the current level represented by an int
	* 	@param *ridKeyPair a pointer to the current ridJeyPair. 
	*   @return a PageKeyPair<int> that represents the ridKeyPair.
	*/
	PageKeyPair<int> *BTreeIndex::insertEntryHelper(PageId currPageNum, int currLevel, RIDKeyPair<int> *ridKeyPair)
	{

		// Read in the current page using the passed in page number
		Page *currentPage;
		this->bufMgr->readPage(this->file, currPageNum, currentPage);

		// Recusive Base Case, ie, current node is level 1
		if (currLevel == 1)
		{

			// Treat curent node as a leaf node
			LeafNodeInt *leaf = reinterpret_cast<LeafNodeInt *>(currentPage);

			// Check if the current node has space to insert //possible bug
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{
				if (leaf->ridArray[i].page_number == INT32_MAX)
				{ // Empty spot

					// Key being inserted into a leaf node so:
					leafOccupancy++;

					// Insert the ridKey pair into a leaf that has space
					leafHelper(true, currPageNum, leaf, ridKeyPair); // Pass hasSpace = true

					return NULL; // No need to return a a pagekeypair, because no splitting, copying, cascading upwards etc.
				}
			}

			// Key will be inserted into a nonleaf node so:
			nodeOccupancy++;

			// Insert the ridKey pair into a full leaf that will need to be split
			// return a PageKeyPair
			return leafHelper(false, currPageNum, leaf, ridKeyPair); // Pass hasSpace = false;
		}

		// Got past base case, so node is not a leaf
		// Cast currnt page toa non leaf node struct
		NonLeafNodeInt *internalNode = reinterpret_cast<NonLeafNodeInt *>(currentPage);

		// Get the page number for the correct child subtree to recur down
		PageId childPageNum = 0;

		// Iterate over the keys in the current internal node
		for (int i = 0; i < INTARRAYNONLEAFSIZE; i++)
		{

			// Key to insert is greater than current page key AND there is only one more key in the array
			if (ridKeyPair->key > internalNode->keyArray[i] && internalNode->pageNoArray[i + 2] == 0)
			{
				// Use the next key's child page for a recusive call
				childPageNum = internalNode->pageNoArray[i + 1];
				break;
			}

			// Key to insert is less than the current page key
			else if (ridKeyPair->key < internalNode->keyArray[i])
			{

				// Use current key's child page for recusive call
				childPageNum = internalNode->pageNoArray[i];
				break;
			}

			// Current key is the last key stored in the current node
			else if (i == INTARRAYNONLEAFSIZE - 1)
			{

				// Use next key's child page for recursive call
				childPageNum = internalNode->pageNoArray[i + 1];
				break;
			}

			// Else move onto the next key
		}

		// No longeer need the current node page so remove it from the buffer pool
		this->bufMgr->unPinPage(file, currPageNum, false); // Page was not modified so no need to set dirty bit

		// Use the childPage number to make a recusive call on one of the current node's children
		PageKeyPair<int> *nodeReturnedFromSplitting = insertEntryHelper(childPageNum, internalNode->level, ridKeyPair);

		// Check if a node was returned
		if (nodeReturnedFromSplitting == NULL)
		{
			return NULL; // No need to return a a pagekeypair, because no splitting, copying, cascading upwards etc.
		}

		// Else need to handle a page being cascaded up the tree

		// Get current node, previous page was deleted prior to recusive call
		this->bufMgr->readPage(this->file, currPageNum, currentPage);

		// Current node is not a leaf node, so cast to an internal node struct
		internalNode = reinterpret_cast<NonLeafNodeInt *>(currentPage);

		// Check if the current node has space to insert
		for (int i = 0; i < INTARRAYNONLEAFSIZE + 1; i++)
		{

			if (internalNode->pageNoArray[i] == 0)
			{ // Empty Slot

				// Insert into an internal node with space
				internalNodeHelper(true, currPageNum, internalNode, nodeReturnedFromSplitting); // pass hasSpace = true
				return NULL;
			}
		}

		// Insert into an internal node that is full
		// return a PageKeyPair
		return internalNodeHelper(false, currPageNum, internalNode, nodeReturnedFromSplitting);
	}

	/*
	*	Helper method for insertEntry in the case of a leafHelper
	*
	*	@param hasSpace that represnted if the current location has space or not. 
	*	@param int currPageNum, the current pagen number represented by an PageId
	* 	@param *leaf a pointer to the current leaf
	*   @param *ridKeyPair, a pointer to the ridKeyPair.
	*   @return a PageKeyPair<int> that represents the leaf.
	*/
	PageKeyPair<int> *BTreeIndex::leafHelper(bool hasSpace, PageId currPageNum, LeafNodeInt *leaf, RIDKeyPair<int> *ridKeyPair)
	{

		// Leaf has space, so simply insert
		if (hasSpace == true)
		{

			// Create a new set of key and rid variables to track values being shifted in the node
			RecordId shiftedRid;
			int shiftedKey;

			// Search for a free slot in the leaf node -> iterate over ridArray
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{

				// if current index is INT_MAX, slot is free
				if (leaf->ridArray[i].page_number == INT32_MAX)
				{

					// Insert rid and key from the pair into the array
					leaf->ridArray[i] = ridKeyPair->rid;
					leaf->keyArray[i] = ridKeyPair->key;

					// Pair has been inserted so break out of loop
					break;
				}

				// If slot is not free, and the key to insert is less than the current key,
				// Insert key, and track current key and rid to insert in another iteration
				// This ensures the key is inserted in the correct spot
				else if (ridKeyPair->key < leaf->keyArray[i])
				{

					// Track the current rid and key at the current index
					shiftedRid = leaf->ridArray[i];
					shiftedKey = leaf->keyArray[i];

					// Insert the passed in rid and key into the current index of the node
					leaf->ridArray[i] = ridKeyPair->rid;
					leaf->keyArray[i] = ridKeyPair->key;

					// Assigned the shifted rid and key to the passed in ridKeyPair to insert at a later iteration
					ridKeyPair->rid = shiftedRid;
					ridKeyPair->key = shiftedKey;
				}
			}

			// No longer need the shifted vars so delete unused memory
			// delete shiftedRid;
			// delete shiftedKey;

			// No longer need the currentPage var so remove from buffer pool
			this->bufMgr->unPinPage(file, currPageNum, true); // Modified page so set dirty bit

			return NULL; // No need to return a a pagekeypair, because no splitting, copying, cascading upwards etc.
		}

		// Leaf is full, so must split and create a new node
		else
		{

			// Create the L2 leaf page, cast to the appropriate struct
			PageId l2PageNum;
			Page *l2Page;
			this->bufMgr->allocPage(file, l2PageNum, l2Page);
			LeafNodeInt *l2LeafStuct = reinterpret_cast<LeafNodeInt *>(l2Page);

			// Initialize l2 leaf's ridArray and keyArray to INT_MAX
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{
				l2LeafStuct->ridArray[i].page_number = INT32_MAX;
				l2LeafStuct->keyArray[i] = INT32_MAX;
			}

			// Set the l2 right sibling as the original leaf's right sibling
			l2LeafStuct->rightSibPageNo = leaf->rightSibPageNo;

			// Set the L1 right sibling as the L2 node
			leaf->rightSibPageNo = l2PageNum;

			// Create key and rid arrays of size one larger in order to split
			int sizePlusOne = INTARRAYLEAFSIZE + 1;
			RecordId onePlusRidArray[sizePlusOne];
			int onePlusKeyArray[sizePlusOne];

			// Compute the indexes on which to split these two arrays
			// Split the array into two arrays, L and L2 where L2 has more elements if it is an odd number
			// Eg. splitting an array of size five would give L.size = 2 and L2.size = 3
			int indexOfLastL1Element = (INTARRAYLEAFSIZE / 2) - 1;
			int indexOfFirstL2Element = indexOfLastL1Element + 1;

			// Copy L1 orginal rids and key AND new rid and key into one plus arrays
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{

				// if the key to insert is less than the current key of L1, insert keyrid pair into one plus arrays
				if (ridKeyPair->key < leaf->keyArray[i])
				{
					onePlusRidArray[i] = ridKeyPair->rid;
					onePlusKeyArray[i] = ridKeyPair->key;

					// Track the L1's current key and rid in the ridKeyPair
					ridKeyPair->set(leaf->ridArray[i], leaf->keyArray[i]);
				}

				// else, simly insert the current L1 rid and key into the one plus arrays
				else
				{
					onePlusRidArray[i] = leaf->ridArray[i];
					onePlusKeyArray[i] = leaf->keyArray[i];
				}
			}

			// If the keyrid pair key is never less than any of the keys in the L1 node, insert the pair into the end of the one plus arrays
			onePlusRidArray[sizePlusOne - 1] = ridKeyPair->rid;
			onePlusKeyArray[sizePlusOne - 1] = ridKeyPair->key;

			// Split the oneplus arrays between the L1 and L2 nodes
			for (int i = 0; i < sizePlusOne; i++)
			{

				// Current element belongs in the L1 node
				if (i <= indexOfLastL1Element)
				{
					leaf->ridArray[i] = onePlusRidArray[i];
					leaf->keyArray[i] = onePlusKeyArray[i];
				}

				// Current element belongs the L2 node
				else
				{

					l2LeafStuct->ridArray[i - indexOfFirstL2Element] = onePlusRidArray[i];
					l2LeafStuct->keyArray[i - indexOfFirstL2Element] = onePlusKeyArray[i];

					// Set newly empty elements of L1's arrays to INT_MAX
					leaf->ridArray[i].page_number = INT32_MAX;
					leaf->keyArray[i] = INT32_MAX;
				}
			}

			// Set return value to be the new L2 node
			PageKeyPair<int> *l2PageKeyPair = new PageKeyPair<int>();

			// Initiailize the return pairs key page number and key
			l2PageKeyPair->set(l2PageNum, onePlusKeyArray[indexOfFirstL2Element]);

			// No longer need the currPage or the l2Page so remove from buffer pool
			this->bufMgr->unPinPage(file, currPageNum, true); // Modified page so set dirty bit
			this->bufMgr->unPinPage(file, l2PageNum, true);	  // Modified page so set dirty bit

			return l2PageKeyPair;
		}
	}


	/*
	*	Helper method for insertEntry in the case of internalNode.  
	*
	*	@param PageId currPageNum tehe curernt page number
	*	@param int currLevel, the current level represented by an int
	* 	@param *ridKeyPair apointer to the current 
	*   @return a PageKeyPair<int> that represents the ridKeyPair.
	*/
	PageKeyPair<int> *BTreeIndex::internalNodeHelper(bool hasSpace, PageId currPageNum, NonLeafNodeInt *internalNode, PageKeyPair<int> *pageKeyPair)
	{
		// Leaf has space, so simply insert
		if (hasSpace == true)
		{

			// Create a new set of key and page variables to track values being shifted in the node
			PageId shiftedPage;
			int shiftedKey;

			// Search for a free slot in the leaf node -> iterate over ridArray
			for (int i = 0; i < INTARRAYNONLEAFSIZE; i++)
			{

				// if next index is 0, slot is free
				if (internalNode->pageNoArray[i + 1] == 0)
				{

					// Insert page and key from the pair
					internalNode->pageNoArray[i + 1] = pageKeyPair->pageNo;
					internalNode->keyArray[i] = pageKeyPair->key;

					// Pair has been inserted so break out of loop
					break;
				}
				// If slot is not free, and the key to insert is less than the current key,
				// Insert key, and track current key and page number to insert in another iteration
				// This ensures the key is inserted in the correct spot
				else if (pageKeyPair->key < internalNode->keyArray[i])
				{

					// Track the current rid and key at the current index
					shiftedPage = internalNode->pageNoArray[i + 1];
					shiftedKey = internalNode->keyArray[i];

					// Insert the passed in pageNo and key into the current index of the node + 1
					internalNode->pageNoArray[i + 1] = pageKeyPair->pageNo;
					internalNode->keyArray[i] = pageKeyPair->key;

					// Assigned the shifted rid and key to the passed in ridKeyPair to insert at a later iteration
					pageKeyPair->pageNo = shiftedPage;
					pageKeyPair->key = shiftedKey;
				}
			}

			// No longer need the shifted vars so delete unused memory
			// delete shiftedPage;
			// delete shiftedKey;

			// No longer need the currentPage var so remove from buffer pool
			this->bufMgr->unPinPage(file, currPageNum, true); // Page has been modified so set dirty bit

			return NULL; // No need to return a a pagekeypair, because no splitting, copying, cascading upwards etc.

			// internalNode is full, so must split and create a new node
		} 
		else
			{

				// Create the iN2 internalNode page, cast to the appropriate struct
				PageId iN2PageNum;
				Page *iN2Page;
				this->bufMgr->allocPage(file, iN2PageNum, iN2Page);
				NonLeafNodeInt *iN2NonLeafStruct = reinterpret_cast<NonLeafNodeInt *>(iN2PageNum);

				// Initialize iN2's pageArray to 0 and keyArray to INT_MAX
				for (int i = 0; i < INTARRAYNONLEAFSIZE; i++)
				{
					iN2NonLeafStruct->pageNoArray[i] = 0;
					iN2NonLeafStruct->keyArray[i] = INT32_MAX;
				}

				// Create key and pageNo arrays of size one larger in order to split
				int sizePlusOne = INTARRAYNONLEAFSIZE + 1;
				PageId onePlusPageArray[sizePlusOne + 1]; // PageNoArray is one larger than the keys array so add 2 instead of 1
				int onePlusKeyArray[sizePlusOne];

				// Compute the index on which to split these two arrays
				// Split the array into two arrays, N and N2 where N2 has more elements if it is an odd number
				// Eg. splitting an array of size five would give N.size = 2 and N2.size = 3
				int indexOfLastiN1Element = (INTARRAYNONLEAFSIZE / 2) - 1;
				int indexOfFirstiN2Element = indexOfLastiN1Element + 1;

				// Copy N1 orginal pageNos and key AND new rid and key into one plus arrays
				for (int i = 0; i < INTARRAYNONLEAFSIZE; i++)
				{

					// if the key to insert is less than the current key of N1, insert keypage pair into one plus arrays
					if (pageKeyPair->key < internalNode->keyArray[i])
					{
						onePlusPageArray[i + 1] = pageKeyPair->pageNo;
						onePlusKeyArray[i] = pageKeyPair->key;

						// Track the N1's current key and pageNo in the ridKeyPair
						pageKeyPair->set(internalNode->pageNoArray[i + 1], internalNode->keyArray[i]);

					}

					// else, simly insert the current N1 pageNo and key into the one plus arrays
					else
					{
						onePlusPageArray[i + 1] = internalNode->pageNoArray[i + 1];
						onePlusKeyArray[i] = internalNode->keyArray[i];
					}
				}

				// If the pageKey pair key is never less than any of the keys in the N1 node, insert the pair into the end of the one plus arrays
				onePlusPageArray[sizePlusOne] = pageKeyPair->pageNo;
				onePlusKeyArray[sizePlusOne - 1] = pageKeyPair->key;

				// Split the oneplus arrays between the iN1 and iN2 nodes
				internalNode->pageNoArray[0] = onePlusPageArray[0];
				for (int i = 0; i < sizePlusOne; i++)
				{

					// Current element belongs in the iN1 node
					if (i <= indexOfLastiN1Element)
					{
						internalNode->pageNoArray[i + 1] = onePlusPageArray[i + 1];
						internalNode->keyArray[i] = onePlusKeyArray[i];
					}

					// Current element belongs the iN2 node
					else
					{
						
						iN2NonLeafStruct->pageNoArray[i - indexOfFirstiN2Element] = onePlusPageArray[i + 1]; //TODO old was i
						iN2NonLeafStruct->keyArray[i - indexOfFirstiN2Element] = onePlusKeyArray[i + 1]; //TODO old was i

						// Set newly empty elements of L1's arrays to INT_MAX
						internalNode->pageNoArray[i + 1] = 0;
						internalNode->keyArray[i] = INT32_MAX;
					}
				}

				// Set return value to be the new L2 node
				PageKeyPair<int> *iN2PageKeyPair = new PageKeyPair<int>();

				// Initiailize the return pairs key page number and key
				iN2PageKeyPair->set(iN2PageNum, onePlusKeyArray[indexOfFirstiN2Element]);

				// No longer need the currPage or the l2Page so remove from buffer pool
				this->bufMgr->unPinPage(file, currPageNum, true); // Modified page so set dirty bit
				this->bufMgr->unPinPage(file, iN2PageNum, true);  // Modified page so set dirty bit

				return iN2PageKeyPair;
			}
		}

	/**
	* Start with creating a node from currentPageNum/CurrentPageData as a starting point.
	* Check if our node is at the end of it's pageNoArray or if the lowValInt is greater than our current key.
	* If so, increment our pageNoArray for our next pageId. If not, check if the lowValInt is less than then current key in our node.
	* If so, set our next pageId to our current node's pageNoArray. If not, check if we are at the end of INTARRAYLEAFSIZE. If yes,
	* increment our pageNoArray for our next pageId. Then check if we are at level 1 to see if we are above the leaf node level.
	* if yes, return a PageKeyPair with the leaf node's first key and pageId. If not, recursively call searchHelper and pass next pageId.
	* @param currPage the current page our search helper is called at.
	* @return PageKeyPair<int> the pageId and key pair for the first leaf that is in our range search.
  	**/
		// -----------------------------------------------------------------------------
		// BTreeIndex::searchHelper
		// -----------------------------------------------------------------------------
		PageKeyPair<int> BTreeIndex::searchHelper(PageId currPage)
		{

			int key;
			PageKeyPair<int> returnPair;
			PageId nextPage;
			//add currentpagedata to frame in buffer pool
			this->bufMgr->readPage(file, currPage, currentPageData);

			//create NonLeaf Node from currentPageData
			NonLeafNodeInt *currentNode = (NonLeafNodeInt *)currentPageData;

			for (int i = 0; i < INTARRAYNONLEAFSIZE; i++)
			{
				//if at the end of the pageNoArray and lowValInt is greater than keyArray
				if (currentNode->pageNoArray[i + 2] == 0 && lowValInt > currentNode->keyArray[i])
				{
					//increment pageNoArray
					nextPage = currentNode->pageNoArray[i + 1];
					break;
				}
				//if current key is greater than lowValInt
				else if (lowValInt < currentNode->keyArray[i])
				{
					//do not increment pageNoArray
					nextPage = currentNode->pageNoArray[i];
					break;
				}
				//if at the end of INTARRAYNONLEAFSIZE
				else if (i == INTARRAYNONLEAFSIZE - 1)
				{
					//increment pageNoArray
					nextPage = currentNode->pageNoArray[i + 1];
					break;
				}
			}
			// at node right above leaf nodes
			if (currentNode->level == 1)
			{
				//Unpin currentPageNum
				bufMgr->unPinPage(file, currPage, false);
				//read nextPage into frame
				this->bufMgr->readPage(file, nextPage, currentPageData);
				//create new node from nextPage in frame (leaf node)
				LeafNodeInt *newNode = (LeafNodeInt *)currentPageData;
				//set key to first key in newNode
				key = newNode->keyArray[0];
				// set 1return PageKeyPair's PageId and Key
				returnPair.set(nextPage, key);
				//return new PageKeyPair
				return returnPair;
			}
			//recursive call to search Helper with nextPage if level == 0
			return searchHelper(nextPage);
		}

		// -----------------------------------------------------------------------------
		// BTreeIndex::startScan
		// -----------------------------------------------------------------------------
		void BTreeIndex::startScan(const void *lowValParm,
								   const Operator lowOpParm,
								   const void *highValParm,
								   const Operator highOpParm)
		{
			//Check if Operators are valid
			//std::cout << lowOpParm << std::endl;
			if (lowOpParm != GT && lowOpParm != GTE)
			{
				throw BadOpcodesException();
			}
			if (highOpParm != LT && highOpParm != LTE)
			{
				throw BadOpcodesException();
			}

			lowOp = lowOpParm;
			highOp = highOpParm;

			lowValInt = *((int *)(lowValParm));
			highValInt = *((int *)(highValParm));

			//throw exception if lowValInt is greater than highValInt
			if (lowValInt > highValInt)
			{
				throw BadScanrangeException();
			}

			//Check if scan is executing
			if (scanExecuting)
			{
				endScan();
			}
			//scan executing now
			scanExecuting = true;

			currentPageNum = rootPageNum;
			PageId firstLeaf;
			//if there are nonleaf nodes
			if (nodeOccupancy != 0)
			{
				//use searchHelper to find pageId
				PageKeyPair<int> leafSearch = searchHelper(currentPageNum);
				//set firstLeaf as pageId from searchHelper
				firstLeaf = leafSearch.pageNo;
			}

			else
			{
				//root node is a leaf node
				firstLeaf = rootPageNum;
			}

			//set currentPageNum to first Leaf
			currentPageNum = firstLeaf;
			//reads currentPageNum into the frame and returns pointer to page (CurrentPageData)
			bufMgr->readPage(file, currentPageNum, currentPageData);
			//create LeafNodeInt pointer from currentPageNum Data
			LeafNodeInt *currentNode = (LeafNodeInt *)currentPageData;

			bool nextKeyFound = false;
			//Find the first index in the leaf node that is in range
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{
				if (currentNode->ridArray[i].page_number == INT32_MAX && currentNode->keyArray[i] != INT32_MAX) {
					currentNode->ridArray[i].page_number = 1;
				}
				//case: last entry in current page
				if (i == INTARRAYLEAFSIZE - 1 || (currentNode->ridArray[i].page_number == INT32_MAX && currentNode->keyArray[i] == INT32_MAX))
				{
					//go to next page
					PageId nextPage = currentNode->rightSibPageNo;
					//no more next pages
					if (nextPage == 0)
					{
						throw NoSuchKeyFoundException();
					}
					//unpin the page
					bufMgr->unPinPage(file, currentPageNum, false);
					//set current page to the next page
					currentPageNum = nextPage;
					//reads "next page's" data into frame and returns as currentPageData
					bufMgr->readPage(file, currentPageNum, currentPageData);
					//increments currentNode with new currentPageData
					currentNode = (LeafNodeInt *)currentPageData;
					//restart entry search at index = 0
					nextEntry = 0;
					nextKeyFound = true;  //not really, but helps us avoid the exception being thrown.
				}
				//Purpose: need to find a key in the range

				//case: if lowOp == GT
				else if (lowOp == GT && currentNode->keyArray[i] > lowValInt)
				{
					//Check if valid with highOp == LT
					if (highOp == LT && currentNode->keyArray[i] < highValInt)
					{
						nextEntry = i;
						nextKeyFound = true;
						break;
					}
					//Check if valid with highOp == LTE
					else if (highOp == LTE && currentNode->keyArray[i] <= highValInt)
					{
						nextEntry = i;
						nextKeyFound = true;
						break;
					}
					//Not valid with highOp
					else
					{
						throw NoSuchKeyFoundException();
					}
				}

				//case: if lowOp == GTE
				else if (lowOp == GTE && currentNode->keyArray[i] >= lowValInt)
				{
					//Check if valid with highOp == LT
					if (highOp == LT && currentNode->keyArray[i] < highValInt)
					{
						nextEntry = i;
						nextKeyFound = true;
						break;
					}
					//Check if valid with highOp == LTE
					else if (highOp == LTE && currentNode->keyArray[i] <= highValInt)
					{
						nextEntry = i;
						nextKeyFound = true;
						break;
					}
					//Not valid with highOp
					else
					{
						throw NoSuchKeyFoundException();
					}
				}

				//case: entry is not in range
				//continue
			}
			if (nextKeyFound == false) {
				throw NoSuchKeyFoundException();
			}
			
		}

		// -----------------------------------------------------------------------------
		// BTreeIndex::scanNext
		// -----------------------------------------------------------------------------
		void BTreeIndex::scanNext(RecordId & outRid)
		{
			//check to see if a scan is initialized or not
			if (!scanExecuting)
			{ //if scan is NOT executing, throw exception.
				throw ScanNotInitializedException();
			}
			LeafNodeInt *currentNode = (LeafNodeInt *)currentPageData;
			//case: highOp is LTE, compare nextEntry key with highValInt
			if (highOp == LTE && currentNode->keyArray[nextEntry] <= highValInt)
			{
				outRid = currentNode->ridArray[nextEntry];
			}
			//case: highOp is LT, compare nextEntry key with highValInt
			else if (highOp == LT && currentNode->keyArray[nextEntry] < highValInt)
			{
				outRid = currentNode->ridArray[nextEntry];
			}
			//case: index is completed
			else
			{
				throw IndexScanCompletedException();
			}

			//Check if nextEntry is the last entry in the leaf or
			//ridArray is at the end in page
			if (nextEntry == INTARRAYLEAFSIZE - 1 ||
				currentNode->ridArray[nextEntry + 1].page_number == INT32_MAX)
			{
				//move to next page from right sibling page
				PageId nextPage = currentNode->rightSibPageNo;
				//throw exception if at last page
				if (nextPage == 0)
				{
					throw IndexScanCompletedException();
				}
				//unpin current page
				bufMgr->unPinPage(file, currentPageNum, false);
				//set current page to the next
				currentPageNum = nextPage;
				//read the new current page (next page) into frame
				bufMgr->readPage(file, currentPageNum, currentPageData);
				//start at the beginning of the page
				nextEntry = 0;
			}
			else
			{
				nextEntry++;
			}
		}

		// -----------------------------------------------------------------------------
		// BTreeIndex::endScan
		// -----------------------------------------------------------------------------
		//
		void BTreeIndex::endScan()
		{
			//if scan is still executing, it must not be initialized. So throw exception.
			if (!scanExecuting)
			{
				throw ScanNotInitializedException();
			}
			//set scanExecuting to false
			scanExecuting = false;

			//unpin page. Page can not be dirty, so assume dirty param = false.
			bool DIRTY_PAGE_BOOLEAN = false;

			//TODO: Iterate through and unpin ALL pages.
			this->bufMgr->unPinPage(this->file, this->currentPageNum, DIRTY_PAGE_BOOLEAN);
		}
	}
