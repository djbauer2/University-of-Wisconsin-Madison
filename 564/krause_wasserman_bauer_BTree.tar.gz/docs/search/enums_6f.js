var searchData=
[
  ['operator',['Operator',['../namespacebadgerdb.html#aad50f9c7a9ef0cbcfe0b025a7aa5cb28',1,'badgerdb']]]
];
