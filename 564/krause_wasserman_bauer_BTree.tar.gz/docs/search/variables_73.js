var searchData=
[
  ['size',['SIZE',['../classbadgerdb_1_1_page.html#ae92d52803502854f97309bae2c14ea55',1,'badgerdb::Page']]],
  ['slot_5fnumber',['slot_number',['../structbadgerdb_1_1_record_id.html#a19ec7b749099499446fdd24d48cec9ef',1,'badgerdb::RecordId']]],
  ['slot_5fnumber_5f',['slot_number_',['../classbadgerdb_1_1_invalid_slot_exception.html#a5d3b75dcd33d02d3e37f49d43837676b',1,'badgerdb::InvalidSlotException::slot_number_()'],['../classbadgerdb_1_1_slot_in_use_exception.html#a0b7f44ef307b8dd15141d4525e1dc522',1,'badgerdb::SlotInUseException::slot_number_()']]],
  ['space_5favailable_5f',['space_available_',['../classbadgerdb_1_1_insufficient_space_exception.html#a689b213938176fdb39b069ac0a6513ff',1,'badgerdb::InsufficientSpaceException']]],
  ['space_5frequested_5f',['space_requested_',['../classbadgerdb_1_1_insufficient_space_exception.html#aa49ce376cb726706446907ff0f3adb78',1,'badgerdb::InsufficientSpaceException']]],
  ['stream_5f',['stream_',['../classbadgerdb_1_1_file.html#a66491f3da08e437a19b6ff21f4332018',1,'badgerdb::File']]],
  ['stringarrayleafsize',['STRINGARRAYLEAFSIZE',['../namespacebadgerdb.html#a13948efcab340128bf8b64a1e292c029',1,'badgerdb']]],
  ['stringarraynonleafsize',['STRINGARRAYNONLEAFSIZE',['../namespacebadgerdb.html#a2eaecf77b111d267b4f0f5470942a958',1,'badgerdb']]],
  ['stringsize',['STRINGSIZE',['../namespacebadgerdb.html#a963f341a4f5c2c97cc2e4ffc7b0aa459',1,'badgerdb']]]
];
